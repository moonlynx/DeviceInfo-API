module.exports = {
    httpHost: "127.0.0.1",
    httpPort: 3001,

    dbServer: "127.0.0.1",
    dbPort: "27017",

    dbName: "dbDeviceInfo",
    username: "readonly",
    password: "readonly",

    cDevices: "Devices",
    
    authDb: "admin" //mongodb auth database
};